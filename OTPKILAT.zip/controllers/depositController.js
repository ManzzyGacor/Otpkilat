const axios = require('axios');
const { sendTelegramNotif } = require('../utils/telegramBot');

const getAxiosConfig = (endpoint, params = {}) => {
    return {
        method: 'GET',
        url: `${process.env.RUMAHOTP_BASE_URL}${endpoint}`,
        headers: {
            'x-apikey': process.env.RUMAHOTP_API_KEY,
            'Accept': 'application/json'
        },
        params: params
    };
};

exports.createDeposit = async (req, res) => {
    try {
        const { amount, payment_id, version } = req.query;
        let endpoint = '/v1/deposit/create';
        
        if (version === 'v2') {
            endpoint = '/v2/deposit/create';
        }

        const response = await axios(getAxiosConfig(endpoint, { amount, payment_id }));
        
        if (response.data && response.data.success) {
            const data = response.data.data;
            const nominal = data.amount || data.total;
            const notifMessage = `<b>Permintaan Deposit Baru!</b>\n\nID: <code>${data.id}</code>\nMetode: ${data.method || payment_id}\nNominal: Rp${nominal}`;
            await sendTelegramNotif(notifMessage);
        }

        res.status(200).json(response.data);
    } catch (error) {
        res.status(500).json(error.response ? error.response.data : { success: false, error: { message: error.message } });
    }
};

exports.checkDeposit = async (req, res) => {
    try {
        const { deposit_id, version } = req.query;
        let endpoint = '/v1/deposit/get_status';
        
        if (version === 'v2') {
            endpoint = '/v2/deposit/get_status';
        }

        const response = await axios(getAxiosConfig(endpoint, { deposit_id }));
        res.status(200).json(response.data);
    } catch (error) {
        res.status(500).json(error.response ? error.response.data : { success: false, error: { message: error.message } });
    }
};

exports.cancelDeposit = async (req, res) => {
    try {
        const { deposit_id } = req.query;
        const response = await axios(getAxiosConfig('/v1/deposit/cancel', { deposit_id }));
        res.status(200).json(response.data);
    } catch (error) {
        res.status(500).json(error.response ? error.response.data : { success: false, error: { message: error.message } });
    }
};